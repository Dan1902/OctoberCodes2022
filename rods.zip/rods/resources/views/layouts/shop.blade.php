<!doctype html>
 <html lang="en">
 <head>
 <meta charset="UTF-8">
 <link href="{{asset('css/shop.css')}}" rel="stylesheet"> 
 <title>shop</title>
 </head>
 <body>
 @yield('body')
 @include('layouts.shopheader')
 </body>
 </html>

 <!doctype html>
 <html lang="en">
 <head>
 <meta charset="UTF-8">
 <link href="{{asset('css/shop.css')}}" rel="stylesheet"> 
 <title>shop</title>
 </head>
 <body>
 @yield('body')
 @include('layouts.shopheader')
 </body>
 </html>
