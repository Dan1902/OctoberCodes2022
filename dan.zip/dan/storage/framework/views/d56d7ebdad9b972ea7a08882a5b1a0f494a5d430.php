
<?php $__env->startSection('body'); ?>
    <div>
        <canvas id="titleChart"></canvas>
    </div>

    <div>
        <canvas id="salesChart"></canvas>
    </div>

    <div class="chart-container" style="position: relative; height:40vh; width:80vw">
        <canvas id="itemsChart"></canvas>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC-21\Documents\db_sales\db_sales\resources\views/dashboard/index.blade.php ENDPATH**/ ?>