

<?php $__env->startSection('body'); ?>
    <h1>Your Shopping Cart</h1>
    <div id="cart-container">
        <div id="cart">
            <i class="fa fa-shopping-cart fa-2x openCloseCart" aria-hidden="true"></i>
            <button id="emptyCart">Empty Cart</button>
        </div>
        <span id="itemCount"></span>
    </div>


    <div id="shoppingCart">
        <div id="cartItemsContainer">
            <h2>Items in your cart</h2>
            <i class="fa fa-times-circle-o fa-3x openCloseCart" aria-hidden="true"></i>
            <div id="cartItems">
                
            </div>
            <button class="btn btn-primary" id="checkout">Checkout</button>;
            <span id="cartTotal"></span>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.html">Shopping Cart</a></li>
        </ul>
    </nav>
    <div class="container container-fluid" id="items">

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC-21\Documents\db_sales\db_sales\resources\views/shop/Index.blade.php ENDPATH**/ ?>