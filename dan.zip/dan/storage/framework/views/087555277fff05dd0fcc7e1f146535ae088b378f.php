<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link href="<?php echo e(asset('css/shop.css')); ?>" rel="stylesheet">
    <title>shop</title>
</head>

<body>
    <?php echo $__env->yieldContent('body'); ?>
    <?php echo $__env->make('layouts.shopheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\PC-21\Documents\db_sales\db_sales\resources\views/layouts/shop.blade.php ENDPATH**/ ?>