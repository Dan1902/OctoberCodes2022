@extends('layouts.base')
@section('body')
    <div>
        <canvas id="titleChart"></canvas>
    </div>

    <div>
        <canvas id="salesChart"></canvas>
    </div>

    <div class="chart-container" style="position: relative; height:40vh; width:80vw">
        <canvas id="itemsChart"></canvas>
    </div>
@endsection
